package com.playo.entity;

public enum EventStatus {
    PAST,ONGOING,FUTURE
}
