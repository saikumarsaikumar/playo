package com.playo.user;

public enum Role {
    USER,ADMIN
}
